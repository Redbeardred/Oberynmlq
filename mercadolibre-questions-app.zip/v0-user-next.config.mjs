/** @type {import('next').NextConfig} */
const nextConfig = {
  // Configuración simplificada
  reactStrictMode: false,
}

export default nextConfig

